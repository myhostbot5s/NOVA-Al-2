package com.sajad.novaai;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private final List<Message> messages = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MessageAdapter adapter;
    private RecyclerView recycler;
    private EditText editMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler = findViewById(R.id.recyclerMessages);
        editMessage = findViewById(R.id.editMessage);
        ImageButton btnSend = findViewById(R.id.btnSend);
        TextView credits = findViewById(R.id.txtCredits);

        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        recycler.setLayoutManager(lm);
        adapter = new MessageAdapter(messages);
        recycler.setAdapter(adapter);

        addMessage(getString(R.string.welcome), false);

        btnSend.setOnClickListener(v -> sendMessage());
        editMessage.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage();
                return true;
            }
            return false;
        });

        // فتح حساب التليجرام عند الضغط على حقوق التطوير
        credits.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/ALAKOT2")));
            } catch (Exception ignored) {
            }
        });
    }

    private void sendMessage() {
        String text = editMessage.getText().toString().trim();
        if (text.isEmpty()) return;
        editMessage.setText("");
        addMessage(text, true);

        // ردّ بعد تأخير بسيط ليبدو كأن الذكاء الاصطناعي يكتب
        handler.postDelayed(() -> addMessage(getBotReply(text), false), 700);
    }

    private void addMessage(String text, boolean fromUser) {
        messages.add(new Message(text, fromUser));
        adapter.notifyItemInserted(messages.size() - 1);
        recycler.scrollToPosition(messages.size() - 1);
    }

    /**
     * هنا مكان الربط مع خدمة الذكاء الاصطناعي الحقيقية.
     * حالياً الردود محلية وبسيطة. لاحقاً استبدل هذه الدالة باستدعاء API
     * (على خيط خلفي) ثم مرّر النتيجة إلى addMessage(...).
     */
    private String getBotReply(String userText) {
        String t = userText.toLowerCase(Locale.ROOT);
        if (t.contains("مرحبا") || t.contains("هلا") || t.contains("السلام") || t.contains("hello") || t.contains("hi")) {
            return "أهلاً وسهلاً! كيف أقدر أساعدك؟ 😊";
        }
        if (t.contains("من انت") || t.contains("من أنت") || t.contains("who are you")) {
            return "أنا Nova AI، مساعدك الذكي. تم تطويري بواسطة سجاد محمد.";
        }
        if (t.contains("شكرا") || t.contains("شكراً") || t.contains("thanks")) {
            return "العفو! أنا هنا دائماً لمساعدتك.";
        }
        return "وصلتني رسالتك: \"" + userText + "\"\nسيتم ربطي قريباً بمحرك ذكاء اصطناعي كامل للرد بشكل أذكى.";
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
