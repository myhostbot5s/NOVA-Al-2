package com.sajad.novaai;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.Holder> {

    private final List<Message> messages;

    public MessageAdapter(List<Message> messages) {
        this.messages = messages;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        Message m = messages.get(position);
        holder.text.setText(m.getText());
        if (m.isFromUser()) {
            holder.row.setGravity(Gravity.RIGHT);
            holder.text.setBackgroundResource(R.drawable.bg_user_bubble);
            holder.avatar.setVisibility(View.GONE);
        } else {
            holder.row.setGravity(Gravity.LEFT);
            holder.text.setBackgroundResource(R.drawable.bg_bot_bubble);
            holder.avatar.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final LinearLayout row;
        final TextView text;
        final ImageView avatar;

        Holder(@NonNull View itemView) {
            super(itemView);
            row = itemView.findViewById(R.id.messageRow);
            text = itemView.findViewById(R.id.txtMessage);
            avatar = itemView.findViewById(R.id.imgAvatar);
        }
    }
}
