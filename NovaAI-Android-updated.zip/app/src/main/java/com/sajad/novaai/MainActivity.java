package com.sajad.novaai;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // ==== حط مفتاح الـ API مالتك هنا بين علامتي التنصيص ====
    private static final String GEMINI_API_KEY = "AQ.Ab8RN6J2C8EOQnc5KdiKf3QhEd17Gs0aqyxG7bZpa26NrvnK3Q";
    private static final String GEMINI_MODEL = "gemini-2.0-flash";
    private static final String GEMINI_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/" + GEMINI_MODEL + ":generateContent";

    private final List<Message> messages = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MessageAdapter adapter;
    private RecyclerView recycler;
    private EditText editMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler = findViewById(R.id.recyclerMessages);
        editMessage = findViewById(R.id.editMessage);
        ImageButton btnSend = findViewById(R.id.btnSend);
        TextView credits = findViewById(R.id.txtCredits);

        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        recycler.setLayoutManager(lm);
        adapter = new MessageAdapter(messages);
        recycler.setAdapter(adapter);

        addMessage(getString(R.string.welcome), false);

        btnSend.setOnClickListener(v -> sendMessage());
        editMessage.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage();
                return true;
            }
            return false;
        });

        // فتح حساب التليجرام عند الضغط على حقوق التطوير
        credits.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/ALAKOT2")));
            } catch (Exception ignored) {
            }
        });
    }

    private void sendMessage() {
        String text = editMessage.getText().toString().trim();
        if (text.isEmpty()) return;
        editMessage.setText("");
        addMessage(text, true);

        // نظهر "..." مؤقتاً لحد ما يوصل رد Gemini الحقيقي
        addMessage("يكتب...", false);
        final int typingIndex = messages.size() - 1;

        new Thread(() -> {
            String reply;
            try {
                reply = askGemini(text);
            } catch (Exception e) {
                reply = "صار خطأ بالاتصال 😕 تأكد من الإنترنت أو من مفتاح الـ API وحاول مرة ثانية.";
            }
            final String finalReply = reply;
            runOnUiThread(() -> {
                messages.remove(typingIndex);
                adapter.notifyItemRemoved(typingIndex);
                addMessage(finalReply, false);
            });
        }).start();
    }

    /**
     * يرسل رسالة المستخدم إلى Gemini API الحقيقي ويرجع النص الناتج.
     * لازم تحط مفتاحك بمتغير GEMINI_API_KEY فوگ.
     */
    private String askGemini(String userText) throws Exception {
        URL url = new URL(GEMINI_URL + "?key=" + GEMINI_API_KEY);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);
        conn.setDoOutput(true);

        JSONObject part = new JSONObject().put("text", userText);
        JSONObject content = new JSONObject().put("parts", new JSONArray().put(part));
        JSONObject body = new JSONObject().put("contents", new JSONArray().put(content));

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }

        if (code < 200 || code >= 300) {
            return "الرد فشل (كود " + code + "). تأكد إن مفتاح الـ API صحيح ومفعّل.";
        }

        JSONObject json = new JSONObject(sb.toString());
        return json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text");
    }

    private void addMessage(String text, boolean fromUser) {
        messages.add(new Message(text, fromUser));
        adapter.notifyItemInserted(messages.size() - 1);
        recycler.scrollToPosition(messages.size() - 1);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
